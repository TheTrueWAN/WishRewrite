The king of the kingdom; a tragic villain: a man willing to sacrifice all he is in order to protect the kingdom from what he thinks will destroy it, only to become the very thing he sought to destroy.
The moral message from Magnifico should be: <b>"No man is an island. Without other people to stand with us we lack the strength we need".</b>

History
	He was once the heir to a kingdom, and was loved by its people. He saw the slow strangle of greed choke his people and lead to the ruin of the kingdom. Thus he decided to never let such failure happen again. He escaped the kingdom with his wife and built the kingdom of [[Rosas]] with his hard work and magic.
Character
	He is a man who loves his kingdom dearly and seeks to protect it from what destroyed the previous kingdom. In the movie it is hinted that his downfall was that he had an egotistical streak that his wife helped him control (credit to friend Alex for pointing this out). Thus if he is to be a tragic villain, then his coping mechanism to his egotistical streak, his wife, should be supplanted by something that feeds it instead, the evil magic that he uses to destroy wishes.