<b>UNRESOLVED</b>

<b>RESOLVED</b>
A room of failed attempts, this is the grassroot of [[The Artist]]
	Used to show [[Asha]] the cost of hard work; a famous work of art in the kingdom was built by someone close to Asha. That someone reveals to him that there were tens if not hundreds of failed attempts before he achieved the masterpiece that people know one for. To the artist, the masterpiece is not special because of its beauty, but because of the time investment and work that it represented for the artist's life.