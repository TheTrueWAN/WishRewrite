The purpose of this rewrite is to capture what I think would be an interesting yet underexplored element in that Disney movie Wish's world:
"Our wishes shouldn't be given to us, but instead grasped with our owns two hands."
To that end:
"It is good that we enjoy our hard work and the fruit it bears."
This idea is found in Ecclesiastes.
