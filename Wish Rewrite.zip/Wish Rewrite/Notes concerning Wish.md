Wish is a movie that had the potential for greatness; just look at the old storyboards. However, my theory is that the old plot didn't convey the theme of the final movie:
"The new generation revitalises the old generation's will to wish and to make those wishes come true with their own two hands".
In order to communicate this theme they cannibalised the plot.
Magnifico represents wishes surrendered in the vain hope that they will "just come true by themselves" in the future.
	
Asha represents the will to strive for one's wish again.

"You're a star"
	This is an important mechanical element to the story, but it is overlooked. It has a double meaning:
	"You are the star of your own story"; an inspirational message about self importance.
	"You are a wishing star and can make wishes"; a mechanical key to the climax of the story. The collective will to wish again is what defeats Magnifico, not that anyone cared.

Asha's 100 year old grandfather is Disney; be it the man or corporation is beyond me.